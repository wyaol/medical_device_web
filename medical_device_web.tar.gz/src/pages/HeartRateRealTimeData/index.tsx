const HeartRateRealTimeData = () => {
    return (<div>
        test
    </div>)
}

export default HeartRateRealTimeData
